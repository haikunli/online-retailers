$(function(){
    (function(){
       var aLi=$('#menu li');
       aLi.each(function(index){
           $(this).click(function(){
               aLi.attr('class','gradient');
           })
       });
    })();
});